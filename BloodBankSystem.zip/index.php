<?php

/**
 * @author Abhinav Bhatnagar
 * @copyright 2018
 * 
 */
require_once("public/index.php");


?>