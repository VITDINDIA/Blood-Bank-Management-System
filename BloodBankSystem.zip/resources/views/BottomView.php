 <section class="py-5">
      <div class="container" >
        <hr />
<div class="row">
  <div class="col-sm-4">
 <div class="well">
 <h3>Services</h3>
 <p >1. Search Hospitals for Blood Banks. </p>
 <p >2. Find Out The Availability of Blood.   </p>
 <p >3. Generate Request for The Blood.  </p>
 <p >4. Navigate Hospitals with The Integrated Google Maps.  </p>
 </div>
 </div>
 <div class="col-sm-4">
 <div class="well">
  <h3>Service Location</h3>
   <?php     $Db_objects->cities();   ?>
 </div>
 </div>
 <div class="col-sm-4">
 <div class="well">
  <h3>Contact Information</h3>
   <p ></p>
   <p >E-mail: abhinav.cse12@gmail.com</p>
 </div>
 </div>
 </div>
        </div>
    </section>