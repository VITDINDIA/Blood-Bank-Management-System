 <section class="py-5">
      <div class="container" >

 <h1>About Us</h1>
         <hr />
        <p>'Blood' is recognized as the most precious element that sustains life. It saves innumerable lives across the world 
        in a variety of conditions. Once in every 2- seconds, someone, somewhere is desperately in need of blood. More than 29 million units of blood components are transfused every year. The need for blood is great - on any given day, approximately 39,000 units of Red Blood Cells are needed. 
        Each year, we could meet only up to 1% (approx) of our nation's demand for blood transfusion.
         
        <strong>Despite the increase in the number of blood banks, blood remains in short supply during emergencies,</strong> mainly attributed 
        to the lack of information and accessibility. 
        We positively believe this tool can overcome most of these challenges by effectively <strong>connecting the hospitals blood bank 
        with the blood recipients</strong>. 
        
 </p>
 
        </div>
    </section>