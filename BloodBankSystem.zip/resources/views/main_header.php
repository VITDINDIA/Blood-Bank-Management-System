<header class="py-5 bg-image-full" style="background-image: url('public/img/banner.png');">
      <img class="img-fluid d-block mx-auto" src="public/img/logo1.png" alt="">
</header>