<?php
require_once('controller/session.php');
require_once('database/database.php');
require_once('controller/dbobject.php');
require_once('controller/user.php');
?>